const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const gridSize = 20;
const rows = canvas.height / gridSize;
const cols = canvas.width / gridSize;

let snake = [
  { x: 10, y: 10 },
  { x: 9, y: 10 },
  { x: 8, y: 10 }
];
let direction = { x: 1, y: 0 };
let food = randomFood();
let score = 0;
let gameOver = false;
let gamePaused = false;
let gameLoopInterval;

const questions = [
  {
    question: "What is the capital of France?",
    options: ["Berlin", "Madrid", "Paris", "Rome"],
    answer: 2
  },
  {
    question: "Which language is used for web apps?",
    options: ["Python", "JavaScript", "C++", "Java"],
    answer: 1
  },
  {
    question: "What does CSS stand for?",
    options: ["Colorful Style Sheets", "Cascading Style Sheets", "Computer Style Sheets", "Creative Style Sheets"],
    answer: 1
  }
];

function randomFood() {
  return {
    x: Math.floor(Math.random() * cols),
    y: Math.floor(Math.random() * rows)
  };
}

function drawSnake() {
  ctx.fillStyle = 'lime';
  snake.forEach(segment => {
    ctx.fillRect(segment.x * gridSize, segment.y * gridSize, gridSize, gridSize);
  });
}

function drawFood() {
  ctx.fillStyle = 'red';
  ctx.fillRect(food.x * gridSize, food.y * gridSize, gridSize, gridSize);
}

function moveSnake() {
  const head = { x: snake[0].x + direction.x, y: snake[0].y + direction.y };

  if (
    head.x < 0 || head.x >= cols ||
    head.y < 0 || head.y >= rows ||
    snake.some(seg => seg.x === head.x && seg.y === head.y)
  ) {
    gameOver = true;
    clearInterval(gameLoopInterval);
    setTimeout(() => alert(`Game Over! Your score: ${score}`), 100);
    return;
  }

  snake.unshift(head);

  if (head.x === food.x && head.y === food.y) {
    pauseGame(); // Pause the game before asking the question
    showQuestion();
    food = randomFood(); // Update food so it's not drawn under the modal
  } else {
    snake.pop();
  }
}

function gameLoop() {
  if (!gamePaused && !gameOver) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    moveSnake();
    drawSnake();
    drawFood();
  }
}

function startGameLoop() {
  gameLoopInterval = setInterval(gameLoop, 100);
}

function pauseGame() {
  gamePaused = true;
}

function resumeGame() {
  gamePaused = false;
}

function showQuestion() {
  const question = questions[Math.floor(Math.random() * questions.length)];
  const modal = document.getElementById('questionModal');
  const overlay = document.getElementById('overlay');
  const optionsDiv = document.getElementById('options');

  document.getElementById('questionText').innerText = question.question;
  optionsDiv.innerHTML = '';
  overlay.style.display = 'block';
  modal.style.display = 'block';

  question.options.forEach((opt, i) => {
    const btn = document.createElement('div');
    btn.classList.add('option');
    btn.innerText = opt;
    btn.onclick = () => {
      modal.style.display = 'none';
      overlay.style.display = 'none';

      if (i === question.answer) {
        document.getElementById('message').innerText = '';
        const tail = snake[snake.length - 1];
        snake.push({ x: tail.x, y: tail.y });
        score++;
      } else {
        document.getElementById('message').innerText = 'Answer is wrong!';
      }

      resumeGame(); // Resume the game after the question
    };
    optionsDiv.appendChild(btn);
  });
}

function moveSnake() {
  const head = { x: snake[0].x + direction.x, y: snake[0].y + direction.y };

  if (
    head.x < 0 || head.x >= cols ||
    head.y < 0 || head.y >= rows ||
    snake.some(seg => seg.x === head.x && seg.y === head.y)
  ) {
    gameOver = true;
    clearInterval(gameLoopInterval);
    showGameOverPopup(); // 👈 Show styled popup
    return;
  }

  snake.unshift(head);

  if (head.x === food.x && head.y === food.y) {
    pauseGame();
    showQuestion();
    food = randomFood();
  } else {
    snake.pop();
  }
}

function showGameOverPopup() {
  document.getElementById('overlay').style.display = 'block';
  document.getElementById('gameOverModal').style.display = 'block';
  document.getElementById('finalScore').innerText = `Your Score: ${score}`;
}

function resetGame() {
  snake = [
    { x: 10, y: 10 },
    { x: 9, y: 10 },
    { x: 8, y: 10 }
  ];
  direction = { x: 1, y: 0 };
  food = randomFood();
  score = 0;
  gameOver = false;
  gamePaused = false;
  document.getElementById('message').innerText = '';
  document.getElementById('overlay').style.display = 'none';
  document.getElementById('gameOverModal').style.display = 'none';
  startGameLoop();
}

document.getElementById('restartBtn').addEventListener('click', resetGame);


document.addEventListener('keydown', e => {
  if (gamePaused) return; // Prevent direction changes while paused

  switch (e.key) {
    case 'ArrowUp':
      if (direction.y === 0) direction = { x: 0, y: -1 };
      break;
    case 'ArrowDown':
      if (direction.y === 0) direction = { x: 0, y: 1 };
      break;
    case 'ArrowLeft':
      if (direction.x === 0) direction = { x: -1, y: 0 };
      break;
    case 'ArrowRight':
      if (direction.x === 0) direction = { x: 1, y: 0 };
      break;
  }
});

startGameLoop();
